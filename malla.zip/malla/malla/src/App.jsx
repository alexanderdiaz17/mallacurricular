import React from 'react';
import { MantineProvider } from '@mantine/core';
import tabla from './components/tabla';

export default function App() {
  return (
    <MantineProvider>
      {tabla}
    </MantineProvider>
  );
}

