import React, { useState } from 'react';
import { Container, TextInput, Button, List, Paper, Text, Group } from '@mantine/core';
import { CheckIcon, TrashIcon } from '@mantine/icons';

const tabla = () => {
  
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);

  
  const addTask = () => {
    if (task.trim() !== '') {
      setTasks([
        ...tasks,
        { id: Date.now(), text: task, completed: false },
      ]);
      setTask('');
    }
  };

  
  const toggleTaskCompletion = (id) => {
    setTasks(tasks.map(task =>
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

 
  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  return (
    <Container size="sm" mt="xl">
      <Paper padding="md" shadow="sm">
        <Text align="center" size="xl" weight={500}>Lista de Tareas</Text>

        <TextInput
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="Escribe una nueva tarea"
          label="Nueva Tarea"
          size="md"
          mt="md"
        />
        <Group position="center" mt="md">
          <Button onClick={addTask} size="md">Agregar Tarea</Button>
        </Group>

        <List spacing="xs" mt="lg">
          {tasks.map(({ id, text, completed }) => (
            <List.Item key={id}>
              <Group position="apart">
                <Text
                  style={{ textDecoration: completed ? 'line-through' : 'none' }}
                  size="sm"
                >
                  {text}
                </Text>
                <Group spacing="xs">
                  <Button
                    variant="outline"
                    color={completed ? 'green' : 'blue'}
                    size="xs"
                    onClick={() => toggleTaskCompletion(id)}
                  >
                    <CheckIcon size={14} />
                  </Button>
                  <Button
                    variant="outline"
                    color="red"
                    size="xs"
                    onClick={() => deleteTask(id)}
                  >
                    <TrashIcon size={14} />
                  </Button>
                </Group>
              </Group>
            </List.Item>
          ))}
        </List>
      </Paper>
    </Container>
  );
};

export default tabla;
